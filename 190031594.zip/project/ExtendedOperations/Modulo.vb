﻿Imports System.ComponentModel.Composition
Imports MefCalculator.MefCalculatorInterfaces

<Export(GetType(IOperation))>
<ExportMetadata("Symbol", "%"c)>
Public Class Modulo
    Implements IOperation

    Public Function Operate(ByVal left As Integer, ByVal right As Integer) As Integer Implements IOperation.Operate
        Return left Mod right
    End Function
End Class
